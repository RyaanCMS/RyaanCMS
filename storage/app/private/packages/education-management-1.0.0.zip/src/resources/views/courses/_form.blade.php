@php $c = $course ?? null; @endphp
<div>
  <label class="block text-sm font-medium text-gray-700 mb-1">Course Title</label>
  <input type="text" name="title" value="{{ old('title', $c->title ?? '') }}" required
    class="w-full rounded-xl border @error('title') border-red-400 @else border-gray-300 @enderror px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
  @error('title')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
</div>
<div class="grid sm:grid-cols-2 gap-5">
  <div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Course Code</label>
    <input type="text" name="code" value="{{ old('code', $c->code ?? '') }}" required
      class="w-full rounded-xl border @error('code') border-red-400 @else border-gray-300 @enderror px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
    @error('code')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
  </div>
  <div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Teacher</label>
    <select name="teacher_id" class="w-full rounded-xl border border-gray-300 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
      <option value="">Unassigned</option>
      @foreach ($teachers as $teacher)
        <option value="{{ $teacher->id }}" @selected(old('teacher_id', $c->teacher_id ?? '') == $teacher->id)>{{ $teacher->name }}</option>
      @endforeach
    </select>
  </div>
</div>
<div class="grid sm:grid-cols-2 gap-5">
  <div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Credits</label>
    <input type="number" name="credits" min="1" max="12" value="{{ old('credits', $c->credits ?? 3) }}" required
      class="w-full rounded-xl border @error('credits') border-red-400 @else border-gray-300 @enderror px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
    @error('credits')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
  </div>
  <div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Fee ($)</label>
    <input type="number" step="0.01" name="fee" min="0" value="{{ old('fee', $c->fee ?? '0.00') }}" required
      class="w-full rounded-xl border @error('fee') border-red-400 @else border-gray-300 @enderror px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
    @error('fee')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
  </div>
</div>
<div>
  <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
  <textarea name="description" rows="3" class="w-full rounded-xl border border-gray-300 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">{{ old('description', $c->description ?? '') }}</textarea>
</div>
<label class="flex items-center gap-2 text-sm text-gray-700">
  <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $c->is_active ?? true)) class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
  Course is active
</label>
