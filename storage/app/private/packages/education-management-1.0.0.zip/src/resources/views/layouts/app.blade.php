<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>@yield('title', 'Dashboard') — EduManage</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
  <style>[x-cloak]{display:none!important}</style>
</head>
<body class="bg-gray-50 font-sans" x-data="{ sidebar: false, userMenu: false }">
  <div class="flex min-h-screen">

    <!-- Sidebar -->
    <aside
      class="fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-gray-100 transform transition-transform duration-200 md:translate-x-0"
      :class="sidebar ? 'translate-x-0' : '-translate-x-full md:translate-x-0'"
    >
      <!-- Logo -->
      <div class="h-16 flex items-center gap-2 px-6 border-b border-gray-100">
        <a href="{{ route('home') }}" class="flex items-center gap-2 text-lg font-bold text-indigo-600">
          <span class="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center">🎓</span>
          EduManage
        </a>
      </div>

      <!-- Nav links -->
      <nav class="p-4 space-y-1 text-sm font-medium flex-1">
        <a
          href="{{ route('dashboard') }}"
          class="flex items-center gap-3 px-3 py-2.5 rounded-xl transition {{ request()->routeIs('dashboard') ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-gray-600 hover:bg-gray-50' }}"
        >
          <span>📊</span> Dashboard
        </a>
        <a
          href="{{ route('courses.index') }}"
          class="flex items-center gap-3 px-3 py-2.5 rounded-xl transition {{ request()->routeIs('courses*') ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-gray-600 hover:bg-gray-50' }}"
        >
          <span>📚</span> Courses
        </a>
        <a
          href="{{ route('enrollments.index') }}"
          class="flex items-center gap-3 px-3 py-2.5 rounded-xl transition {{ request()->routeIs('enrollments*') ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-gray-600 hover:bg-gray-50' }}"
        >
          <span>👨‍🎓</span> Enrollments
        </a>
        <a
          href="{{ route('students.index') }}"
          class="flex items-center gap-3 px-3 py-2.5 rounded-xl transition {{ request()->routeIs('students*') ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-gray-600 hover:bg-gray-50' }}"
        >
          <span>🧑‍💻</span> Students
        </a>
        <a
          href="{{ route('teachers.index') }}"
          class="flex items-center gap-3 px-3 py-2.5 rounded-xl transition {{ request()->routeIs('teachers*') ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-gray-600 hover:bg-gray-50' }}"
        >
          <span>👩‍🏫</span> Teachers
        </a>
        <a
          href="{{ route('departments.index') }}"
          class="flex items-center gap-3 px-3 py-2.5 rounded-xl transition {{ request()->routeIs('departments*') ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-gray-600 hover:bg-gray-50' }}"
        >
          <span>🏛️</span> Departments
        </a>
      </nav>

      <!-- Logout -->
      <div class="absolute bottom-0 inset-x-0 p-4 border-t border-gray-100">
        <form method="POST" action="{{ route('logout') }}">
          @csrf
          <button
            type="submit"
            class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-gray-600 hover:bg-red-50 hover:text-red-600 transition text-sm font-medium"
          >
            <span>🚪</span> Logout
          </button>
        </form>
      </div>
    </aside>

    <!-- Mobile overlay -->
    <div
      x-show="sidebar"
      x-cloak
      @click="sidebar = false"
      class="fixed inset-0 bg-black/30 z-30 md:hidden"
    ></div>

    <!-- Main content -->
    <div class="flex-1 md:ml-64 min-w-0">

      <!-- Top header -->
      <header class="h-16 bg-white border-b border-gray-100 flex items-center justify-between px-6 sticky top-0 z-20">
        <!-- Mobile hamburger -->
        <button
          @click="sidebar = !sidebar"
          class="md:hidden text-gray-600 hover:text-gray-900 p-1"
          aria-label="Toggle menu"
        >
          <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/>
          </svg>
        </button>

        <h1 class="text-lg font-bold text-gray-900">@yield('title', 'Dashboard')</h1>

        <!-- User menu -->
        <div class="relative">
          <button
            @click="userMenu = !userMenu"
            class="flex items-center gap-2 hover:opacity-80 transition"
          >
            <span class="w-9 h-9 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
              {{ strtoupper(substr(auth()->user()->name ?? 'U', 0, 1)) }}
            </span>
            <span class="hidden sm:block text-sm font-medium text-gray-700">
              {{ auth()->user()->name ?? 'User' }}
            </span>
            <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
            </svg>
          </button>

          <!-- Dropdown -->
          <div
            x-show="userMenu"
            x-cloak
            @click.away="userMenu = false"
            x-transition:enter="transition ease-out duration-100"
            x-transition:enter-start="opacity-0 scale-95"
            x-transition:enter-end="opacity-100 scale-100"
            x-transition:leave="transition ease-in duration-75"
            x-transition:leave-start="opacity-100 scale-100"
            x-transition:leave-end="opacity-0 scale-95"
            class="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border border-gray-100 py-1 text-sm z-50"
          >
            <div class="px-4 py-2 text-xs text-gray-400 border-b border-gray-100 truncate">
              {{ auth()->user()->email ?? '' }}
            </div>
            <form method="POST" action="{{ route('logout') }}">
              @csrf
              <button
                type="submit"
                class="w-full text-left px-4 py-2.5 text-red-600 hover:bg-red-50 transition font-medium"
              >
                🚪 Logout
              </button>
            </form>
          </div>
        </div>
      </header>

      <!-- Flash messages -->
      <div class="px-6 pt-6">
        @if (session('success'))
          <div
            x-data="{ show: true }"
            x-show="show"
            x-init="setTimeout(() => show = false, 4000)"
            class="mb-4 rounded-xl bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3 flex items-center justify-between"
          >
            <span>✅ {{ session('success') }}</span>
            <button @click="show = false" class="text-green-500 hover:text-green-700 ml-4 font-bold">&times;</button>
          </div>
        @endif
        @if (session('error'))
          <div
            x-data="{ show: true }"
            x-show="show"
            x-init="setTimeout(() => show = false, 4000)"
            class="mb-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 flex items-center justify-between"
          >
            <span>❌ {{ session('error') }}</span>
            <button @click="show = false" class="text-red-500 hover:text-red-700 ml-4 font-bold">&times;</button>
          </div>
        @endif
      </div>

      <!-- Page content -->
      <main class="p-6">
        @yield('content')
      </main>
    </div>
  </div>

  <!-- Powered by RyaanCMS -->
  <div id="ryaancms-attr" style="position:fixed;bottom:12px;right:12px;z-index:9999;display:flex;align-items:center;gap:6px;padding:5px 11px;background:rgba(255,255,255,0.95);border:1px solid #e2e8f0;border-radius:20px;box-shadow:0 2px 12px rgba(0,0,0,0.08);font-family:system-ui,-apple-system,sans-serif;font-size:11px;font-weight:500;color:#64748b;backdrop-filter:blur(8px);pointer-events:none;user-select:none;">
    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
    Powered by RyaanCMS v1.0.0
  </div>
</body>
</html>
