@extends('layouts.app')
@section('title', 'Courses')

@section('content')
<div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6">
  <form method="GET" action="{{ route('courses.index') }}" class="flex-1 max-w-sm">
    <div class="relative">
      <input type="text" name="search" value="{{ request('search') }}" placeholder="Search courses..."
        class="w-full rounded-xl border border-gray-200 pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
      <svg class="w-4 h-4 text-gray-400 absolute left-3.5 top-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
    </div>
  </form>
  <a href="{{ route('courses.create') }}" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm shadow-lg shadow-indigo-200 text-center">+ New Course</a>
</div>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
        <tr>
          <th class="text-left px-6 py-3 font-semibold">Course</th>
          <th class="text-left px-6 py-3 font-semibold">Teacher</th>
          <th class="text-left px-6 py-3 font-semibold">Credits</th>
          <th class="text-left px-6 py-3 font-semibold">Fee</th>
          <th class="text-left px-6 py-3 font-semibold">Status</th>
          <th class="text-right px-6 py-3 font-semibold">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-50">
        @forelse ($courses as $course)
        <tr class="hover:bg-gray-50">
          <td class="px-6 py-4">
            <p class="font-medium text-gray-900">{{ $course->title }}</p>
            <p class="text-xs text-gray-500">{{ $course->code }}</p>
          </td>
          <td class="px-6 py-4 text-gray-600">{{ $course->teacher->name ?? 'Unassigned' }}</td>
          <td class="px-6 py-4 text-gray-600">{{ $course->credits }}</td>
          <td class="px-6 py-4 text-gray-600">${{ number_format((float) $course->fee, 2) }}</td>
          <td class="px-6 py-4">
            <span class="text-xs font-semibold px-2.5 py-1 rounded-full {{ $course->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500' }}">{{ $course->is_active ? 'Active' : 'Inactive' }}</span>
          </td>
          <td class="px-6 py-4">
            <div class="flex items-center justify-end gap-2" x-data="{ confirm: false }">
              <a href="{{ route('courses.show', $course) }}" class="text-gray-500 hover:text-indigo-600" title="View">👁</a>
              <a href="{{ route('courses.edit', $course) }}" class="text-gray-500 hover:text-indigo-600" title="Edit">✏️</a>
              <button @click="confirm = true" class="text-gray-500 hover:text-red-600" title="Delete">🗑</button>
              <div x-show="confirm" x-cloak class="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" @click="confirm = false">
                <div @click.stop class="bg-white rounded-2xl p-6 max-w-sm w-full text-center">
                  <p class="font-bold text-gray-900">Delete this course?</p>
                  <p class="text-sm text-gray-500 mt-1">"{{ $course->title }}" will be permanently removed.</p>
                  <div class="mt-5 flex gap-3 justify-center">
                    <button @click="confirm = false" class="px-4 py-2 rounded-xl border border-gray-200 text-sm font-medium">Cancel</button>
                    <form method="POST" action="{{ route('courses.destroy', $course) }}">
                      @csrf @method('DELETE')
                      <button class="px-4 py-2 rounded-xl bg-red-600 text-white text-sm font-medium">Delete</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
        @empty
        <tr><td colspan="6" class="px-6 py-10 text-center text-gray-400">No courses found.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>

<div class="mt-6">{{ $courses->links() }}</div>
@endsection
