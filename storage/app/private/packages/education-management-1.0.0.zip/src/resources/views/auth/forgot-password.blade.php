@extends('layouts.auth')

@section('title', 'Forgot Password — EduManage')

@section('content')
<div>
  <h2 class="text-2xl font-bold text-gray-900 mb-1">Reset your password</h2>
  <p class="text-sm text-gray-500 mb-8">Enter your email and we'll send you a reset link.</p>

  @if (session('status'))
    <div class="mb-4 rounded-xl bg-green-50 border border-green-200 text-green-700 text-sm px-4 py-3">
      {{ session('status') }}
    </div>
  @endif

  <form method="POST" action="{{ route('password.email') }}" x-data="{ loading: false }" @submit="loading = true">
    @csrf

    <div class="mb-6">
      <label class="block text-sm font-medium text-gray-700 mb-1.5" for="email">Email Address</label>
      <input
        type="email"
        id="email"
        name="email"
        value="{{ old('email') }}"
        required
        placeholder="you@example.com"
        class="w-full rounded-xl border px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition {{ $errors->has('email') ? 'border-red-400 bg-red-50' : 'border-gray-200 bg-gray-50' }}"
      >
      @error('email')
        <p class="mt-1.5 text-xs text-red-600">{{ $message }}</p>
      @enderror
    </div>

    <button
      type="submit"
      :disabled="loading"
      class="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-semibold py-3 rounded-xl text-sm shadow-lg shadow-indigo-200 transition flex items-center justify-center gap-2"
    >
      <svg x-show="loading" class="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/></svg>
      <span x-text="loading ? 'Sending...' : 'Send Reset Link'"></span>
    </button>
  </form>

  <p class="mt-6 text-center text-sm text-gray-500">
    Remembered your password?
    <a href="{{ route('login') }}" class="text-indigo-600 font-semibold hover:underline">Back to Sign In</a>
  </p>
</div>
@endsection
