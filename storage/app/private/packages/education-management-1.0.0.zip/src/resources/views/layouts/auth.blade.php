<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>@yield('title', 'EduManage')</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-gradient-to-br from-indigo-50 via-white to-purple-50 min-h-screen flex items-center justify-center p-4 font-sans">
  <div class="w-full max-w-5xl bg-white rounded-3xl shadow-2xl overflow-hidden grid md:grid-cols-2">
    <div class="hidden md:flex flex-col justify-between bg-gradient-to-br from-indigo-600 to-purple-700 p-10 text-white">
      <a href="{{ route('home') }}" class="flex items-center gap-2 text-xl font-bold">
        <span class="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">🎓</span>
        EduManage
      </a>
      <div>
        <h2 class="text-3xl font-bold leading-snug">Manage your institution with ease.</h2>
        <p class="mt-3 text-indigo-100 text-sm">Courses, students, teachers and enrollments — all in one beautiful dashboard.</p>
      </div>
      <p class="text-xs text-indigo-200">&copy; {{ date('Y') }} EduManage. All rights reserved.</p>
    </div>
    <div class="p-8 sm:p-12">
      <a href="{{ route('home') }}" class="md:hidden flex items-center gap-2 text-lg font-bold text-indigo-600 mb-6">
        <span class="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center">🎓</span>
        EduManage
      </a>
      @yield('content')
    </div>
  </div>

  <!-- Powered by RyaanCMS -->
  <div id="ryaancms-attr" style="position:fixed;bottom:12px;right:12px;z-index:9999;display:flex;align-items:center;gap:6px;padding:5px 11px;background:rgba(255,255,255,0.95);border:1px solid #e2e8f0;border-radius:20px;box-shadow:0 2px 12px rgba(0,0,0,0.08);font-family:system-ui,-apple-system,sans-serif;font-size:11px;font-weight:500;color:#64748b;backdrop-filter:blur(8px);pointer-events:none;user-select:none;">
    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
    Powered by RyaanCMS v1.0.0
  </div>
</body>
</html>
