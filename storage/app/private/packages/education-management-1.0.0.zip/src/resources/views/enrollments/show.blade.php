@extends('layouts.app')
@section('title', 'Enrollment Details')

@section('content')
<div class="max-w-2xl">
  <a href="{{ route('enrollments.index') }}" class="text-sm text-indigo-600 hover:underline">&larr; Back to enrollments</a>
  <div class="mt-4 bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
    <div class="flex items-center justify-between">
      <h2 class="text-xl font-bold text-gray-900">{{ $enrollment->student->name ?? 'Unknown' }}</h2>
      <span class="text-xs font-semibold px-3 py-1 rounded-full {{ $enrollment->status === 'active' ? 'bg-green-100 text-green-700' : ($enrollment->status === 'completed' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600') }}">{{ ucfirst($enrollment->status) }}</span>
    </div>
    <dl class="mt-6 grid sm:grid-cols-2 gap-5 text-sm">
      <div>
        <dt class="text-gray-500">Course</dt>
        <dd class="font-medium text-gray-900">{{ $enrollment->course->title ?? 'Unknown' }} ({{ $enrollment->course->code ?? '' }})</dd>
      </div>
      <div>
        <dt class="text-gray-500">Instructor</dt>
        <dd class="font-medium text-gray-900">{{ $enrollment->course->teacher->name ?? 'Unassigned' }}</dd>
      </div>
      <div>
        <dt class="text-gray-500">Enrolled On</dt>
        <dd class="font-medium text-gray-900">{{ $enrollment->enrolled_on?->format('F d, Y') }}</dd>
      </div>
      <div>
        <dt class="text-gray-500">Grade</dt>
        <dd class="font-medium text-gray-900">{{ $enrollment->grade ?: 'Not graded' }}</dd>
      </div>
    </dl>
    <div class="mt-8 flex gap-3">
      <a href="{{ route('enrollments.edit', $enrollment) }}" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm">Edit</a>
      <form method="POST" action="{{ route('enrollments.destroy', $enrollment) }}" x-data @submit.prevent="if(confirm('Remove this enrollment?')) $el.submit()">
        @csrf @method('DELETE')
        <button class="px-5 py-2.5 rounded-xl border border-red-200 text-red-600 text-sm font-medium hover:bg-red-50">Remove</button>
      </form>
    </div>
  </div>
</div>
@endsection
