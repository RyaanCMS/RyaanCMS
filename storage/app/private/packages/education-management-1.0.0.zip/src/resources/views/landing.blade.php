<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EduManage — Modern Education Management</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body id="top" class="font-sans text-gray-800 bg-white">

  <!-- Navbar -->
  <nav x-data="{ open: false }" class="sticky top-0 z-50 bg-white/80 backdrop-blur border-b border-gray-100">
    <div class="max-w-7xl mx-auto px-6 flex items-center justify-between h-16">
      <a href="{{ route('home') }}" class="flex items-center gap-2 text-xl font-bold text-indigo-600">
        <span class="w-9 h-9 rounded-xl bg-indigo-100 flex items-center justify-center">🎓</span>
        EduManage
      </a>
      <div class="hidden md:flex items-center gap-8 text-sm font-medium text-gray-600">
        <a href="#features" class="hover:text-indigo-600">Features</a>
        <a href="#pricing" class="hover:text-indigo-600">Pricing</a>
        <a href="{{ route('login') }}" class="hover:text-indigo-600">Sign In</a>
        <a href="{{ route('register') }}" class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-xl shadow-lg shadow-indigo-200">Get Started</a>
      </div>
      <button @click="open = !open" class="md:hidden text-gray-600">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
      </button>
    </div>
    <div x-show="open" x-cloak class="md:hidden border-t border-gray-100 px-6 py-4 space-y-3 text-sm font-medium">
      <a href="#features" class="block text-gray-600">Features</a>
      <a href="#pricing" class="block text-gray-600">Pricing</a>
      <a href="{{ route('login') }}" class="block text-gray-600">Sign In</a>
      <a href="{{ route('register') }}" class="block bg-indigo-600 text-white px-5 py-2 rounded-xl text-center">Get Started</a>
    </div>
  </nav>

  <!-- Hero -->
  <section id="hero" class="bg-gradient-to-br from-indigo-50 via-white to-purple-50">
    <div class="max-w-7xl mx-auto px-6 py-24 text-center">
      <span class="inline-block bg-indigo-100 text-indigo-700 text-xs font-semibold px-4 py-1.5 rounded-full mb-6">🚀 Now serving 500+ institutions</span>
      <h1 class="text-4xl sm:text-6xl font-extrabold text-gray-900 leading-tight">Education management,<br><span class="text-indigo-600">beautifully simple.</span></h1>
      <p class="mt-6 text-lg text-gray-600 max-w-2xl mx-auto">Manage students, teachers, courses and enrollments from one elegant dashboard. Spend less time on admin, more time teaching.</p>
      <div class="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
        <a href="{{ route('register') }}" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-8 py-3.5 rounded-xl shadow-lg shadow-indigo-200 transition">Get Started Free</a>
        <a href="{{ route('login') }}" class="bg-white hover:bg-gray-50 text-gray-700 font-semibold px-8 py-3.5 rounded-xl border border-gray-200 transition">Sign In</a>
      </div>
    </div>
  </section>

  <!-- Features -->
  <section id="features" class="max-w-7xl mx-auto px-6 py-24">
    <div class="text-center mb-16">
      <h2 class="text-3xl font-bold text-gray-900">Everything you need</h2>
      <p class="mt-3 text-gray-600">A complete toolkit to run your institution.</p>
    </div>
    <div class="grid md:grid-cols-3 gap-8">
      @foreach ([['📚','Course Management','Create, organize and track unlimited courses with credits and fees.'],['👨‍🎓','Student Enrollments','Enroll students, assign grades and monitor progress in real time.'],['👩‍🏫','Teacher Assignments','Assign instructors to courses and manage their teaching load.']] as [$icon, $title, $desc])
      <div class="bg-white rounded-2xl border border-gray-100 p-8 shadow-sm hover:shadow-lg transition">
        <div class="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center text-2xl mb-5">{{ $icon }}</div>
        <h3 class="text-lg font-bold text-gray-900">{{ $title }}</h3>
        <p class="mt-2 text-sm text-gray-600">{{ $desc }}</p>
      </div>
      @endforeach
    </div>
  </section>

  <!-- Pricing -->
  <section id="pricing" class="bg-gray-50 py-24">
    <div class="max-w-7xl mx-auto px-6">
      <div class="text-center mb-16">
        <h2 class="text-3xl font-bold text-gray-900">Simple pricing</h2>
        <p class="mt-3 text-gray-600">Choose the plan that fits your institution.</p>
      </div>
      <div class="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        @foreach ([['Starter','$0','Up to 50 students','border-gray-100','bg-white text-indigo-600 border border-indigo-200'],['Professional','$49','Up to 500 students','border-indigo-500 ring-2 ring-indigo-500','bg-indigo-600 text-white'],['Enterprise','Custom','Unlimited everything','border-gray-100','bg-white text-indigo-600 border border-indigo-200']] as [$plan, $price, $desc, $ring, $btn])
        <div class="bg-white rounded-2xl p-8 shadow-sm {{ $ring }}">
          <h3 class="text-lg font-bold text-gray-900">{{ $plan }}</h3>
          <p class="mt-4 text-4xl font-extrabold text-gray-900">{{ $price }}<span class="text-base font-medium text-gray-400">/mo</span></p>
          <p class="mt-2 text-sm text-gray-600">{{ $desc }}</p>
          <a href="{{ route('register') }}" class="mt-6 block text-center font-semibold px-6 py-2.5 rounded-xl {{ $btn }}">Get Started</a>
        </div>
        @endforeach
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="bg-gradient-to-br from-indigo-600 to-purple-700 py-20">
    <div class="max-w-4xl mx-auto px-6 text-center text-white">
      <h2 class="text-3xl font-bold">Ready to get started?</h2>
      <p class="mt-3 text-indigo-100">Create your free account in under a minute.</p>
      <a href="{{ route('register') }}" class="mt-8 inline-block bg-white text-indigo-600 font-semibold px-8 py-3.5 rounded-xl shadow-lg hover:bg-gray-50 transition">Get Started Free</a>
    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-gray-900 text-gray-400 py-12">
    <div class="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
      <a href="{{ route('home') }}" class="flex items-center gap-2 text-white font-bold text-lg">
        <span class="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">🎓</span>
        EduManage
      </a>
      <p class="text-sm">&copy; {{ date('Y') }} EduManage. All rights reserved.</p>
      <div class="flex gap-6 text-sm">
        <a href="#features" class="hover:text-white">Features</a>
        <a href="#pricing" class="hover:text-white">Pricing</a>
        <a href="{{ route('login') }}" class="hover:text-white">Sign In</a>
      </div>
    </div>
  </footer>

  <!-- Powered by RyaanCMS -->
  <div id="ryaancms-attr" style="position:fixed;bottom:12px;right:12px;z-index:9999;display:flex;align-items:center;gap:6px;padding:5px 11px;background:rgba(255,255,255,0.95);border:1px solid #e2e8f0;border-radius:20px;box-shadow:0 2px 12px rgba(0,0,0,0.08);font-family:system-ui,-apple-system,sans-serif;font-size:11px;font-weight:500;color:#64748b;backdrop-filter:blur(8px);pointer-events:none;user-select:none;">
    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
    Powered by RyaanCMS v1.0.0
  </div>
</body>
</html>
