@extends('layouts.app')
@section('title', 'New Enrollment')

@section('content')
<div class="max-w-2xl">
  <a href="{{ route('enrollments.index') }}" class="text-sm text-indigo-600 hover:underline">&larr; Back to enrollments</a>
  <div class="mt-4 bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
    <h2 class="text-xl font-bold text-gray-900 mb-6">Create Enrollment</h2>
    <form method="POST" action="{{ route('enrollments.store') }}" class="space-y-5" x-data="{ loading: false }" @submit="loading = true">
      @csrf
      @include('enrollments._form')
      <div class="flex gap-3 pt-2">
        <button type="submit" :disabled="loading" class="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-semibold px-6 py-2.5 rounded-xl text-sm flex items-center gap-2">
          <svg x-show="loading" class="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path></svg>
          Save Enrollment
        </button>
        <a href="{{ route('enrollments.index') }}" class="px-6 py-2.5 rounded-xl border border-gray-200 text-sm font-medium">Cancel</a>
      </div>
    </form>
  </div>
</div>
@endsection
