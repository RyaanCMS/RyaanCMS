@extends('layouts.auth')

@section('title', 'Create Account — EduManage')

@section('content')
<div>
  <h2 class="text-2xl font-bold text-gray-900 mb-1">Create your account</h2>
  <p class="text-sm text-gray-500 mb-8">Start managing your institution for free</p>

  @if (session('error'))
    <div class="mb-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3">
      {{ session('error') }}
    </div>
  @endif

  <form method="POST" action="{{ route('register.attempt') }}" x-data="{ loading: false }" @submit="loading = true">
    @csrf

    {{-- Name --}}
    <div class="mb-5">
      <label class="block text-sm font-medium text-gray-700 mb-1.5" for="name">Full Name</label>
      <input
        type="text"
        id="name"
        name="name"
        value="{{ old('name') }}"
        required
        autocomplete="name"
        placeholder="Sarah Mitchell"
        class="w-full rounded-xl border px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition {{ $errors->has('name') ? 'border-red-400 bg-red-50' : 'border-gray-200 bg-gray-50' }}"
      >
      @error('name')
        <p class="mt-1.5 text-xs text-red-600">{{ $message }}</p>
      @enderror
    </div>

    {{-- Email --}}
    <div class="mb-5">
      <label class="block text-sm font-medium text-gray-700 mb-1.5" for="email">Email Address</label>
      <input
        type="email"
        id="email"
        name="email"
        value="{{ old('email') }}"
        required
        autocomplete="email"
        placeholder="you@example.com"
        class="w-full rounded-xl border px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition {{ $errors->has('email') ? 'border-red-400 bg-red-50' : 'border-gray-200 bg-gray-50' }}"
      >
      @error('email')
        <p class="mt-1.5 text-xs text-red-600">{{ $message }}</p>
      @enderror
    </div>

    {{-- Password --}}
    <div class="mb-5" x-data="{ show: false }">
      <label class="block text-sm font-medium text-gray-700 mb-1.5" for="password">Password</label>
      <div class="relative">
        <input
          :type="show ? 'text' : 'password'"
          id="password"
          name="password"
          required
          autocomplete="new-password"
          placeholder="Min. 8 characters"
          class="w-full rounded-xl border px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition pr-12 {{ $errors->has('password') ? 'border-red-400 bg-red-50' : 'border-gray-200 bg-gray-50' }}"
        >
        <button type="button" @click="show = !show" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs">
          <span x-text="show ? 'Hide' : 'Show'"></span>
        </button>
      </div>
      @error('password')
        <p class="mt-1.5 text-xs text-red-600">{{ $message }}</p>
      @enderror
    </div>

    {{-- Confirm Password --}}
    <div class="mb-6" x-data="{ show: false }">
      <label class="block text-sm font-medium text-gray-700 mb-1.5" for="password_confirmation">Confirm Password</label>
      <div class="relative">
        <input
          :type="show ? 'text' : 'password'"
          id="password_confirmation"
          name="password_confirmation"
          required
          autocomplete="new-password"
          placeholder="Repeat your password"
          class="w-full rounded-xl border px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition pr-12 border-gray-200 bg-gray-50"
        >
        <button type="button" @click="show = !show" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs">
          <span x-text="show ? 'Hide' : 'Show'"></span>
        </button>
      </div>
    </div>

    {{-- Submit --}}
    <button
      type="submit"
      :disabled="loading"
      class="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-semibold py-3 rounded-xl text-sm shadow-lg shadow-indigo-200 transition flex items-center justify-center gap-2"
    >
      <svg x-show="loading" class="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/></svg>
      <span x-text="loading ? 'Creating account...' : 'Create Account'"></span>
    </button>
  </form>

  <p class="mt-6 text-center text-sm text-gray-500">
    Already have an account?
    <a href="{{ route('login') }}" class="text-indigo-600 font-semibold hover:underline">Sign in</a>
  </p>
</div>
@endsection
