@php $e = $enrollment ?? null; @endphp
<div>
  <label class="block text-sm font-medium text-gray-700 mb-1">Student</label>
  <select name="student_id" required class="w-full rounded-xl border @error('student_id') border-red-400 @else border-gray-300 @enderror px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
    <option value="">Select a student</option>
    @foreach ($students as $student)
      <option value="{{ $student->id }}" @selected(old('student_id', $e->student_id ?? '') == $student->id)>{{ $student->name }}</option>
    @endforeach
  </select>
  @error('student_id')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
</div>
<div>
  <label class="block text-sm font-medium text-gray-700 mb-1">Course</label>
  <select name="course_id" required class="w-full rounded-xl border @error('course_id') border-red-400 @else border-gray-300 @enderror px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
    <option value="">Select a course</option>
    @foreach ($courses as $courseOpt)
      <option value="{{ $courseOpt->id }}" @selected(old('course_id', $e->course_id ?? '') == $courseOpt->id)>{{ $courseOpt->title }} ({{ $courseOpt->code }})</option>
    @endforeach
  </select>
  @error('course_id')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
</div>
<div class="grid sm:grid-cols-2 gap-5">
  <div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
    <select name="status" required class="w-full rounded-xl border border-gray-300 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
      @foreach (['active' => 'Active', 'completed' => 'Completed', 'dropped' => 'Dropped'] as $val => $label)
        <option value="{{ $val }}" @selected(old('status', $e->status ?? 'active') === $val)>{{ $label }}</option>
      @endforeach
    </select>
  </div>
  <div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Grade (optional)</label>
    <input type="text" name="grade" maxlength="5" value="{{ old('grade', $e->grade ?? '') }}" placeholder="A, B+, ..."
      class="w-full rounded-xl border border-gray-300 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
  </div>
</div>
<div>
  <label class="block text-sm font-medium text-gray-700 mb-1">Enrollment Date</label>
  <input type="date" name="enrolled_on" value="{{ old('enrolled_on', isset($e) && $e->enrolled_on ? $e->enrolled_on->format('Y-m-d') : now()->format('Y-m-d')) }}" required
    class="w-full rounded-xl border @error('enrolled_on') border-red-400 @else border-gray-300 @enderror px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
  @error('enrolled_on')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
</div>
