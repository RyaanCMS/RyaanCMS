@extends('layouts.app')
@section('title', 'Enrollments')

@section('content')
<div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6">
  <form method="GET" action="{{ route('enrollments.index') }}" class="flex gap-3">
    <select name="status" onchange="this.form.submit()" class="rounded-xl border border-gray-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
      <option value="">All statuses</option>
      <option value="active" @selected(request('status') === 'active')>Active</option>
      <option value="completed" @selected(request('status') === 'completed')>Completed</option>
      <option value="dropped" @selected(request('status') === 'dropped')>Dropped</option>
    </select>
  </form>
  <a href="{{ route('enrollments.create') }}" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm shadow-lg shadow-indigo-200 text-center">+ New Enrollment</a>
</div>

<div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
        <tr>
          <th class="text-left px-6 py-3 font-semibold">Student</th>
          <th class="text-left px-6 py-3 font-semibold">Course</th>
          <th class="text-left px-6 py-3 font-semibold">Enrolled</th>
          <th class="text-left px-6 py-3 font-semibold">Grade</th>
          <th class="text-left px-6 py-3 font-semibold">Status</th>
          <th class="text-right px-6 py-3 font-semibold">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-50">
        @forelse ($enrollments as $e)
        <tr class="hover:bg-gray-50">
          <td class="px-6 py-4 font-medium text-gray-900">{{ $e->student->name ?? 'Unknown' }}</td>
          <td class="px-6 py-4 text-gray-600">{{ $e->course->title ?? 'Unknown' }}</td>
          <td class="px-6 py-4 text-gray-600">{{ $e->enrolled_on?->format('M d, Y') }}</td>
          <td class="px-6 py-4 text-gray-600">{{ $e->grade ?: '—' }}</td>
          <td class="px-6 py-4">
            <span class="text-xs font-semibold px-2.5 py-1 rounded-full {{ $e->status === 'active' ? 'bg-green-100 text-green-700' : ($e->status === 'completed' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600') }}">{{ ucfirst($e->status) }}</span>
          </td>
          <td class="px-6 py-4">
            <div class="flex items-center justify-end gap-2" x-data="{ confirm: false }">
              <a href="{{ route('enrollments.show', $e) }}" class="text-gray-500 hover:text-indigo-600" title="View">👁</a>
              <a href="{{ route('enrollments.edit', $e) }}" class="text-gray-500 hover:text-indigo-600" title="Edit">✏️</a>
              <button @click="confirm = true" class="text-gray-500 hover:text-red-600" title="Delete">🗑</button>
              <div x-show="confirm" x-cloak class="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" @click="confirm = false">
                <div @click.stop class="bg-white rounded-2xl p-6 max-w-sm w-full text-center">
                  <p class="font-bold text-gray-900">Remove this enrollment?</p>
                  <div class="mt-5 flex gap-3 justify-center">
                    <button @click="confirm = false" class="px-4 py-2 rounded-xl border border-gray-200 text-sm font-medium">Cancel</button>
                    <form method="POST" action="{{ route('enrollments.destroy', $e) }}">
                      @csrf @method('DELETE')
                      <button class="px-4 py-2 rounded-xl bg-red-600 text-white text-sm font-medium">Remove</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
        @empty
        <tr><td colspan="6" class="px-6 py-10 text-center text-gray-400">No enrollments found.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>

<div class="mt-6">{{ $enrollments->links() }}</div>
@endsection
