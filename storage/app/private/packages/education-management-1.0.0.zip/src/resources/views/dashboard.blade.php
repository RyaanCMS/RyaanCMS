@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
<div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
  @php
    $cards = [
      ['Students', $stats['students'], '👨‍🎓', 'from-indigo-500 to-indigo-600'],
      ['Teachers', $stats['teachers'], '👩‍🏫', 'from-purple-500 to-purple-600'],
      ['Courses', $stats['courses'], '📚', 'from-blue-500 to-blue-600'],
      ['Active Enrollments', $stats['enrollments'], '📈', 'from-green-500 to-green-600'],
    ];
  @endphp
  @foreach ($cards as [$label, $value, $icon, $grad])
  <div class="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
    <div class="flex items-center justify-between">
      <div class="w-12 h-12 rounded-xl bg-gradient-to-br {{ $grad }} flex items-center justify-center text-2xl text-white">{{ $icon }}</div>
    </div>
    <p class="mt-4 text-3xl font-extrabold text-gray-900">{{ $value }}</p>
    <p class="text-sm text-gray-500">{{ $label }}</p>
  </div>
  @endforeach
</div>

<div class="mt-8 flex flex-wrap gap-3">
  <a href="{{ route('courses.create') }}" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm shadow-lg shadow-indigo-200">+ New Course</a>
  <a href="{{ route('enrollments.create') }}" class="bg-white hover:bg-gray-50 text-gray-700 font-semibold px-5 py-2.5 rounded-xl text-sm border border-gray-200">+ New Enrollment</a>
</div>

<div class="mt-8 grid lg:grid-cols-2 gap-6">
  <!-- Recent Enrollments -->
  <div class="bg-white rounded-2xl border border-gray-100 shadow-sm">
    <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
      <h2 class="font-bold text-gray-900">Recent Enrollments</h2>
      <a href="{{ route('enrollments.index') }}" class="text-sm text-indigo-600 hover:underline">View all</a>
    </div>
    <div class="divide-y divide-gray-50">
      @forelse ($recentEnrollments as $e)
      <div class="px-6 py-3 flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-gray-900">{{ $e->student->name ?? 'Unknown' }}</p>
          <p class="text-xs text-gray-500">{{ $e->course->title ?? 'Unknown course' }}</p>
        </div>
        <span class="text-xs font-semibold px-2.5 py-1 rounded-full {{ $e->status === 'active' ? 'bg-green-100 text-green-700' : ($e->status === 'completed' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600') }}">{{ ucfirst($e->status) }}</span>
      </div>
      @empty
      <p class="px-6 py-6 text-sm text-gray-400 text-center">No enrollments yet.</p>
      @endforelse
    </div>
  </div>

  <!-- Recent Courses -->
  <div class="bg-white rounded-2xl border border-gray-100 shadow-sm">
    <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
      <h2 class="font-bold text-gray-900">Recent Courses</h2>
      <a href="{{ route('courses.index') }}" class="text-sm text-indigo-600 hover:underline">View all</a>
    </div>
    <div class="divide-y divide-gray-50">
      @forelse ($recentCourses as $c)
      <div class="px-6 py-3 flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-gray-900">{{ $c->title }}</p>
          <p class="text-xs text-gray-500">{{ $c->code }} • {{ $c->teacher->name ?? 'Unassigned' }}</p>
        </div>
        <span class="text-xs font-semibold text-gray-700">${{ number_format((float) $c->fee, 2) }}</span>
      </div>
      @empty
      <p class="px-6 py-6 text-sm text-gray-400 text-center">No courses yet.</p>
      @endforelse
    </div>
  </div>
</div>
@endsection
