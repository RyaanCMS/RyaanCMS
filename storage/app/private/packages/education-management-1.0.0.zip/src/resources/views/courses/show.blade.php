@extends('layouts.app')
@section('title', 'Course Details')

@section('content')
<div class="max-w-3xl">
  <a href="{{ route('courses.index') }}" class="text-sm text-indigo-600 hover:underline">&larr; Back to courses</a>
  <div class="mt-4 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
    <div class="bg-gradient-to-br from-indigo-600 to-purple-700 p-8 text-white">
      <span class="text-xs font-semibold bg-white/20 px-3 py-1 rounded-full">{{ $course->code }}</span>
      <h2 class="mt-3 text-2xl font-bold">{{ $course->title }}</h2>
      <p class="mt-1 text-indigo-100 text-sm">{{ $course->teacher->name ?? 'Unassigned' }} • {{ $course->credits }} credits • ${{ number_format((float) $course->fee, 2) }}</p>
    </div>
    <div class="p-8 space-y-6">
      <div>
        <h3 class="text-sm font-semibold text-gray-500 uppercase">Description</h3>
        <p class="mt-2 text-gray-700">{{ $course->description ?: 'No description provided.' }}</p>
      </div>
      <div>
        <h3 class="text-sm font-semibold text-gray-500 uppercase">Enrolled Students ({{ $course->enrollments->count() }})</h3>
        <div class="mt-3 divide-y divide-gray-50 border border-gray-100 rounded-xl">
          @forelse ($course->enrollments as $e)
          <div class="px-4 py-3 flex items-center justify-between text-sm">
            <span class="font-medium text-gray-900">{{ $e->student->name ?? 'Unknown' }}</span>
            <span class="text-xs font-semibold px-2.5 py-1 rounded-full {{ $e->status === 'active' ? 'bg-green-100 text-green-700' : ($e->status === 'completed' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600') }}">{{ ucfirst($e->status) }}{{ $e->grade ? ' • '.$e->grade : '' }}</span>
          </div>
          @empty
          <p class="px-4 py-4 text-sm text-gray-400 text-center">No students enrolled yet.</p>
          @endforelse
        </div>
      </div>
      <div class="flex gap-3 pt-2">
        <a href="{{ route('courses.edit', $course) }}" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm">Edit Course</a>
        <form method="POST" action="{{ route('courses.destroy', $course) }}" x-data @submit.prevent="if(confirm('Delete this course?')) $el.submit()">
          @csrf @method('DELETE')
          <button class="px-5 py-2.5 rounded-xl border border-red-200 text-red-600 text-sm font-medium hover:bg-red-50">Delete</button>
        </form>
      </div>
    </div>
  </div>
</div>
@endsection
